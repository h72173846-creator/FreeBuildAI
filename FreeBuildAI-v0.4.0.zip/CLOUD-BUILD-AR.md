# البناء السحابي v0.4.0

## الصلاحيات المطلوبة للرمز
Fine-grained PAT للمستودع:
- **Contents: Read and write** (لرفع المشاريع المولَّدة)
- **Actions: Read and write** (لتشغيل ومتابعة البناء)

## المسارات
- `android-app/` = تطبيق FreeBuild نفسه
- `generated-apps/<اسم>/` = مشاريع مولَّدة تُرفع من الواجهة

Workflow يقبل `project_path` اختياريًا.
