# FreeBuild AI Android source (v0.2.0)

## Build APK
1. Install Android Studio on a computer and ensure Android SDK Platform 35 is installed.
2. Open this `android-app` folder as a project.
3. Allow Gradle sync, then choose **Build > Build APK(s)**.

This session does not have an Android SDK/Gradle installation available, so no compiled APK is included. The app includes a WebView wrapper and a native HTTP bridge for OpenAI-compatible Chat Completions APIs, avoiding browser CORS on Android. The key is provided per session from the UI and not written to local storage.

## API configuration
Enter an HTTPS API base URL, model name, and your own key in app settings. Provider compatibility, pricing/limits, and model availability vary. Keep keys private; this is a personal prototype, not a hardened production service. Do not use on shared devices.

## Scope
The model responds with suggested plans/code in the result panel. It does not automatically edit arbitrary local files or compile APKs. A full production product needs a secure backend and isolated build/test workers.
