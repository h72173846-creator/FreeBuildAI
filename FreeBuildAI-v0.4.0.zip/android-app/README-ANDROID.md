# FreeBuild AI Android source (v0.3.0)

WebView wrapper + native bridge for Chat Completions and GitHub API (HTTPS only).

Build with Android Studio (SDK 35) or the included GitHub Actions workflow. This package does not ship a prebuilt APK.

API keys and GitHub tokens stay in page memory only; never commit them.
