package com.freebuildai.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URI;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AIConnector(), "FreeBuildBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("file:///android_asset/");
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class AIConnector {
        @JavascriptInterface public void openUrl(String url) {
            runOnUiThread(() -> {
                try {
                    URL parsed = new URL(url);
                    if (!"https".equalsIgnoreCase(parsed.getProtocol())) return;
                    if (!(parsed.getHost().equalsIgnoreCase("github.com") || parsed.getHost().equalsIgnoreCase("api.github.com"))) return;
                    Intent intent = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
                    startActivity(intent);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void githubRequest(String method, String path, String token, String body, String callbackId) {
            EXECUTOR.execute(() -> {
                JSONObject result = new JSONObject(); HttpURLConnection connection = null;
                try {
                    if (token == null || token.trim().isEmpty()) throw new IllegalArgumentException("أدخل رمز GitHub.");
                    if (path == null || !path.startsWith("/repos/") || path.contains("..") || path.contains("\\")) throw new IllegalArgumentException("مسار GitHub غير مسموح.");
                    if (!("GET".equals(method) || "POST".equals(method) || "PUT".equals(method))) throw new IllegalArgumentException("طريقة الطلب غير مسموحة.");
                    URL url = new URL("https://api.github.com" + path);
                    if (!"api.github.com".equalsIgnoreCase(url.getHost()) || !"https".equalsIgnoreCase(url.getProtocol())) throw new IllegalArgumentException("عنوان GitHub غير مسموح.");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod(method); connection.setConnectTimeout(20000); connection.setReadTimeout(30000);
                    connection.setRequestProperty("Accept", "application/vnd.github+json");
                    connection.setRequestProperty("Authorization", "Bearer " + token.trim());
                    connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28");
                    if ("POST".equals(method) || "PUT".equals(method)) {
                        connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                        byte[] payload = (body == null ? "{}" : body).getBytes("UTF-8");
                        connection.setFixedLengthStreamingMode(payload.length);
                        try (OutputStream os = connection.getOutputStream()) { os.write(payload); }
                    }
                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder sb = new StringBuilder();
                    if (stream != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"))) { String line; while ((line = br.readLine()) != null) sb.append(line); }
                    result.put("status", code);
                    if (sb.length() > 0) { try { result.put("data", new JSONObject(sb.toString())); } catch (Exception ignored) { result.put("data", new JSONObject()); } }
                    else result.put("data", new JSONObject());
                } catch (Exception e) {
                    try { result.put("error", e.getMessage() == null ? "تعذر الاتصال بـ GitHub." : e.getMessage()); } catch (Exception ignored) {}
                } finally { if (connection != null) connection.disconnect(); }
                final String answer = result.toString();
                runOnUiThread(() -> webView.evaluateJavascript("window.__freebuildGhResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(answer) + ")", null));
            });
        }
        @JavascriptInterface public void complete(String baseUrl, String model, String apiKey, String requestBody, String callbackId) {
            EXECUTOR.execute(() -> {
                JSONObject result = new JSONObject();
                HttpURLConnection connection = null;
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("أدخل مفتاح API.");
                    if (model == null || model.trim().isEmpty()) throw new IllegalArgumentException("أدخل اسم النموذج.");
                    URL base = new URL(baseUrl);
                    if (!"https".equalsIgnoreCase(base.getProtocol())) throw new IllegalArgumentException("يجب استخدام HTTPS.");
                    String host = base.getHost() == null ? "" : base.getHost().toLowerCase();
                    if (host.isEmpty() || host.equals("localhost") || host.endsWith(".local") || host.equals("0.0.0.0") || host.equals("127.0.0.1") || host.startsWith("10.") || host.startsWith("192.168.") || host.startsWith("172.16.") || host.startsWith("172.17.") || host.startsWith("172.18.") || host.startsWith("172.19.") || host.startsWith("172.2") || host.startsWith("172.30.") || host.startsWith("172.31.")) throw new IllegalArgumentException("عنوان الخدمة يبدو محليًا أو غير مسموح.");
                    String urlText = baseUrl.replaceAll("/+$", "");
                    if (!urlText.matches("(?i).*/chat/completions$")) urlText += "/chat/completions";
                    connection = (HttpURLConnection) new URL(urlText).openConnection();
                    connection.setRequestMethod("POST"); connection.setConnectTimeout(25000); connection.setReadTimeout(120000);
                    connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
                    byte[] payload = requestBody.getBytes("UTF-8"); connection.setFixedLengthStreamingMode(payload.length);
                    try (OutputStream os = connection.getOutputStream()) { os.write(payload); }
                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder sb = new StringBuilder();
                    if (stream != null) { try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"))) { String line; while ((line = br.readLine()) != null) sb.append(line); } }
                    JSONObject response = new JSONObject(sb.toString());
                    if (code < 200 || code >= 300) {
                        String msg = response.optJSONObject("error") != null ? response.optJSONObject("error").optString("message", "HTTP " + code) : "HTTP " + code;
                        result.put("ok", false); result.put("error", msg);
                    } else {
                        JSONArray choices = response.optJSONArray("choices");
                        String content = "";
                        if (choices != null && choices.length() > 0) { JSONObject choice = choices.optJSONObject(0); JSONObject message = choice == null ? null : choice.optJSONObject("message"); if (message != null) content = message.optString("content", ""); }
                        if (content.isEmpty()) { result.put("ok", false); result.put("error", "لم يرجع النموذج محتوى نصيًا."); }
                        else { result.put("ok", true); result.put("content", content); }
                    }
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage() == null ? "تعذر الاتصال بالخدمة." : e.getMessage()); } catch (Exception ignored) {}
                } finally { if (connection != null) connection.disconnect(); }
                final String answer = result.toString();
                runOnUiThread(() -> webView.evaluateJavascript("window.__freebuildAiResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(answer) + ")", null));
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
