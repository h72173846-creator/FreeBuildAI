# بناء APK من GitHub

1. فك ضغط الحزمة.
2. أنشئ مستودع GitHub وارفع المحتويات (بما فيها `.github` و `android-app`).
3. من تبويب Actions شغّل **Build FreeBuild AI APK**.
4. بعد النجاح نزّل **FreeBuildAI-debug-APK** وثبّت `app-debug.apk`.

نسخة Debug غير موقّعة للمتجر. البناء يحتاج Actions وإنترنت لتنزيل Gradle وSDK.

## من FreeBuild AI نفسه
لوحة البناء داخل التطبيق ترسل `workflow_dispatch` وتتابع الحالة. يلزم Token محدود الصلاحيات.

## مشاريع مولَّدة بالـ AI
نزّل ZIP المشروع من الواجهة، ارفعه للمستودع، وعدّل مسار البناء في الـ workflow إن لزم، ثم أعد التشغيل.
