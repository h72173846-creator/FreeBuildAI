# FreeBuild AI — prototype v0.2.0

Arabic RTL app-building assistant prototype. Includes project prompt creation, improve/debug modes, text-file context (sent only when you ask the configured AI provider), local work settings, TXT export and starter HTML export.

## Open in browser
Open `index.html`. To use AI, configure an OpenAI-compatible API base URL (typically ending in `/v1`), model, and your own API key, then test the connection. In browsers, requests may be blocked by provider CORS rules. The API key is not saved to local storage.

## Android project
`android-app/` is an Android Studio source project with WebView and native HTTPS API bridge. Build it with Android Studio and Android SDK Platform 35. This environment does not have Gradle/Android SDK, so this archive contains source rather than a compiled APK.

## Important limitations
AI returns suggestions/code as text; this version does not safely execute generated code, modify a project directory automatically, or build APKs by itself. Those capabilities need a secure backend and isolated build infrastructure. Never put permanent API keys in app source.

## Licensing
Prototype code is offered under the MIT License in `LICENSE`. Review licenses for any models, libraries, fonts, imagery, and third-party services added later.
