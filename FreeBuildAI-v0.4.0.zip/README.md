# FreeBuild AI — v0.4.0

واجهة عربية: وصف → ملفات أندرويد من AI → رفع تلقائي إلى GitHub → تشغيل بناء APK.

## التدفق
1. اربط مزوّد AI (مفتاحك).
2. اربط مستودع GitHub بـ Token: **Contents Read and write** + **Actions Read and write**.
3. ارفع محتويات هذه الحزمة للمستودع مرة واحدة (android-app + .github + index.html).
4. اكتب وصف التطبيق → تنفيذ AI → استخراج ملفات → **رفع إلى GitHub + بناء APK**.
5. من صفحة التشغيل نزّل Artifact `FreeBuildAI-debug-APK`.

## حدود
- تنزيل الـ APK يتم من GitHub Artifacts (الأضمن على الموبايل).
- جودة المشروع تعتمد على النموذج.
- لا يوجد خادم بناء مجاني عام بدون حسابك.

MIT — راجع LICENSE.
