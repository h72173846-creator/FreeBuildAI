package com.freebuildai.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.net.URI;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AIConnector(), "FreeBuildBridge");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("file:///android_asset/");
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class AIConnector {
        @JavascriptInterface public void complete(String baseUrl, String model, String apiKey, String requestBody, String callbackId) {
            EXECUTOR.execute(() -> {
                JSONObject result = new JSONObject();
                HttpURLConnection connection = null;
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new IllegalArgumentException("أدخل مفتاح API.");
                    if (model == null || model.trim().isEmpty()) throw new IllegalArgumentException("أدخل اسم النموذج.");
                    URL base = new URL(baseUrl);
                    if (!"https".equalsIgnoreCase(base.getProtocol())) throw new IllegalArgumentException("يجب استخدام HTTPS.");
                    String host = base.getHost() == null ? "" : base.getHost().toLowerCase();
                    if (host.isEmpty() || host.equals("localhost") || host.endsWith(".local") || host.equals("0.0.0.0") || host.equals("127.0.0.1") || host.startsWith("10.") || host.startsWith("192.168.") || host.startsWith("172.16.") || host.startsWith("172.17.") || host.startsWith("172.18.") || host.startsWith("172.19.") || host.startsWith("172.2") || host.startsWith("172.30.") || host.startsWith("172.31.")) throw new IllegalArgumentException("عنوان الخدمة يبدو محليًا أو غير مسموح.");
                    String urlText = baseUrl.replaceAll("/+$", "");
                    if (!urlText.matches("(?i).*/chat/completions$")) urlText += "/chat/completions";
                    connection = (HttpURLConnection) new URL(urlText).openConnection();
                    connection.setRequestMethod("POST"); connection.setConnectTimeout(25000); connection.setReadTimeout(120000);
                    connection.setDoOutput(true); connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    connection.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
                    byte[] payload = requestBody.getBytes("UTF-8"); connection.setFixedLengthStreamingMode(payload.length);
                    try (OutputStream os = connection.getOutputStream()) { os.write(payload); }
                    int code = connection.getResponseCode();
                    InputStream stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder sb = new StringBuilder();
                    if (stream != null) { try (BufferedReader br = new BufferedReader(new InputStreamReader(stream, "UTF-8"))) { String line; while ((line = br.readLine()) != null) sb.append(line); } }
                    JSONObject response = new JSONObject(sb.toString());
                    if (code < 200 || code >= 300) {
                        String msg = response.optJSONObject("error") != null ? response.optJSONObject("error").optString("message", "HTTP " + code) : "HTTP " + code;
                        result.put("ok", false); result.put("error", msg);
                    } else {
                        JSONArray choices = response.optJSONArray("choices");
                        String content = "";
                        if (choices != null && choices.length() > 0) { JSONObject choice = choices.optJSONObject(0); JSONObject message = choice == null ? null : choice.optJSONObject("message"); if (message != null) content = message.optString("content", ""); }
                        if (content.isEmpty()) { result.put("ok", false); result.put("error", "لم يرجع النموذج محتوى نصيًا."); }
                        else { result.put("ok", true); result.put("content", content); }
                    }
                } catch (Exception e) {
                    try { result.put("ok", false); result.put("error", e.getMessage() == null ? "تعذر الاتصال بالخدمة." : e.getMessage()); } catch (Exception ignored) {}
                } finally { if (connection != null) connection.disconnect(); }
                final String answer = result.toString();
                runOnUiThread(() -> webView.evaluateJavascript("window.__freebuildAiResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(answer) + ")", null));
            });
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
